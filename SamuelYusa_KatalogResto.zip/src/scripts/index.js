import 'regenerator-runtime'; /* for async await transpile */
import '../styles/main.css';
import './script.js';
import main from './main';

console.log('Hello Coders! :)');

main();

